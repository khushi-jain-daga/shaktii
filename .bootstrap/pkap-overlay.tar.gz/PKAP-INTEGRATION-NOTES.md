# Pkap Analyzer integration notes

Functional source-of-truth: the supplied LogSentry project.
Visual source-of-truth: the existing SHAKTII / SIH26 frontend.

Pages included inside the Pkap Analyzer workspace:

1. Upload Center
2. Current Report
3. Reports History
4. Threat Intelligence
5. Documentation
6. Settings

Threat Intelligence layout intentionally preserves the source product's chart proportions: a maximum 1200px content area, responsive two-column landscape/trending panels, and a 300px Recharts activity chart. It is not rendered as a full-screen SVG.
